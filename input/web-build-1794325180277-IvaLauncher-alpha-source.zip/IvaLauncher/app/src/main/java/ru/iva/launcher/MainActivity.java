package ru.iva.launcher;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(15,17,18), panel = Color.rgb(27,29,29), amber = Color.rgb(235,139,38), white = Color.rgb(235,232,224), muted = Color.rgb(153,151,143);
    private LinearLayout root;
    @Override public void onCreate(Bundle b) { super.onCreate(b); getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg); getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); build(); }
    private GradientDrawable shape(int color, int stroke) { GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(18); if(stroke>0)d.setStroke(2,stroke); return d; }
    private TextView text(String s,int size,int color,boolean bold) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t; }
    private void build() {
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,20,28,18); root.setBackgroundColor(bg); setContentView(root);
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); root.addView(top,new LinearLayout.LayoutParams(-1,54));
        TextView brand=text("AVENSIS  /  ИВА",16,amber,true); top.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        TextView clock=text(new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date()),22,white,true); top.addView(clock);
        TextView date=text(new SimpleDateFormat("EEEE, d MMMM",new Locale("ru")).format(new Date()),12,muted,false); date.setGravity(Gravity.RIGHT); root.addView(date,new LinearLayout.LayoutParams(-1,24));
        LinearLayout body=new LinearLayout(this); body.setOrientation(LinearLayout.HORIZONTAL); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,0,1); bp.topMargin=14; bp.bottomMargin=14; root.addView(body,bp);
        LinearLayout left=new LinearLayout(this); left.setOrientation(LinearLayout.VERTICAL); left.setPadding(22,18,22,18); left.setBackground(shape(panel,0)); body.addView(left,new LinearLayout.LayoutParams(0,-1,1.25f));
        left.addView(text("ДОБРО ПОЖАЛОВАТЬ",12,amber,true)); TextView car=text("TOYOTA\nAVENSIS",34,white,true); car.setGravity(Gravity.CENTER); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,0,1); left.addView(car,cp); left.addView(text("T25  •  YOUR DRIVE, YOUR RULES",11,muted,true));
        LinearLayout right=new LinearLayout(this); right.setOrientation(LinearLayout.VERTICAL); LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,-1,1); rp.leftMargin=14; body.addView(right,rp);
        LinearLayout row1=new LinearLayout(this); right.addView(row1,new LinearLayout.LayoutParams(-1,0,1)); addTile(row1,"МУЗЫКА","Открыть плеер", "music"); addTile(row1,"НАВИГАЦИЯ","Маршрут и карты", "maps");
        LinearLayout row2=new LinearLayout(this); LinearLayout.LayoutParams r2=new LinearLayout.LayoutParams(-1,0,1); r2.topMargin=12; right.addView(row2,r2); addTile(row2,"ТЕЛЕФОН","Звонки и связь", "phone"); addTile(row2,"ПРИЛОЖЕНИЯ","Все приложения", "apps");
        LinearLayout bottom=new LinearLayout(this); bottom.setGravity(Gravity.CENTER_VERTICAL); root.addView(bottom,new LinearLayout.LayoutParams(-1,38));
        bottom.addView(text("ИВА  •  ВЕРСИЯ 0.1 ALPHA",10,muted,true),new LinearLayout.LayoutParams(0,-2,1)); bottom.addView(text("ЯНТАРНАЯ ТЕМА",10,amber,true));
    }
    private void addTile(LinearLayout row,String title,String sub,String action) {
        LinearLayout tile=new LinearLayout(this); tile.setOrientation(LinearLayout.VERTICAL); tile.setGravity(Gravity.CENTER_VERTICAL); tile.setPadding(18,12,12,12); tile.setBackground(shape(panel,Color.rgb(75,55,35)));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1); if(row.getChildCount()>0)p.leftMargin=10; row.addView(tile,p);
        TextView dot=text("●",16,amber,true); tile.addView(dot); TextView h=text(title,17,white,true); LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2); hp.topMargin=8; tile.addView(h,hp); TextView st=text(sub,11,muted,false); tile.addView(st);
        tile.setOnClickListener(v -> launch(action));
    }
    private void launch(String a) {
        if(a.equals("apps")){ startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS)); return; }
        String[] pkgs;
        if(a.equals("maps")) pkgs=new String[]{"com.google.android.apps.maps","ru.yandex.yandexmaps"};
        else if(a.equals("music")) pkgs=new String[]{"com.google.android.apps.youtube.music","com.spotify.music","com.android.music"};
        else pkgs=new String[]{"com.google.android.dialer","com.android.dialer"};
        PackageManager pm=getPackageManager();
        for(String pkg:pkgs){ Intent i=pm.getLaunchIntentForPackage(pkg); if(i!=null){startActivity(i);return;} }
        Toast.makeText(this,"Подходящее приложение не найдено. Добавим выбор приложений в следующей версии.",Toast.LENGTH_LONG).show();
    }
}
