package ru.iva.launcher;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.*;

public class MainActivity extends Activity {
  private static final int BG=Color.rgb(2,7,16), PANEL=Color.rgb(7,18,33), BLUE=Color.rgb(0,174,255), WHITE=Color.rgb(239,247,255), MUTED=Color.rgb(132,158,184), CYAN=Color.rgb(48,218,255);
  private static final UUID SPP=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
  private final Handler ui=new Handler(); private boolean showingTrd=false; private LinearLayout root,trdPage; private TextView clock,date,obdState,obdConnect; private GaugeView rpmGauge,speedGauge; private final String[] slots={"Навигация","Музыка","Телефон","Радио","Видео","Приложения","TRD","Настройки"};
  private final String[] actions={"maps","music","phone","radio","video","apps","trd","settings"};
  private final String[] defaults={"ru.yandex.yandexmaps","com.android.music","com.android.dialer","com.syu.radio","com.google.android.youtube","","",""};
  private final String[] defaultIcons={"➤","♫","☎","▣","▶","▦","TRD","⚙"};
  private final String[] iconChoices={"➤","♫","☎","▣","▶","▦","TRD","⚙","★","♥","☀","☾","✉","◎","◉","◆","●","＋"};
  private BluetoothSocket socket; private volatile int obdGeneration=0; private volatile boolean obdRunning=false; private Thread obdThread; private volatile int rpm=-1,speed=-1,coolant=-1,intake=-1,load=-1,throttle=-1,manifold=-1,timing=-1,barometric=-1; private volatile double maf=-1; private volatile String obdMessage="OBD2 НЕ ПОДКЛЮЧЁН";
  private final Runnable tick=()->{ if(clock!=null)clock.setText(new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date())); if(date!=null)date.setText(new SimpleDateFormat("EEEE, d MMMM",new Locale("ru")).format(new Date())); ui.postDelayed(this.tick,15000); };
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_STABLE);buildHome();tick.run();}
  @Override protected void onDestroy(){ui.removeCallbacks(tick);disconnectObd();super.onDestroy();}
  @Override public void onBackPressed(){if(showingTrd){closeTrd(trdPage);}else{super.onBackPressed();}}
  private GradientDrawable shape(int color,int stroke,int radius){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(Math.min(255,Color.red(color)+8),Math.min(255,Color.green(color)+15),Math.min(255,Color.blue(color)+25)),Color.rgb(3,10,21),Color.rgb(5,17,31)});d.setCornerRadius(radius);d.setStroke(2,stroke);return d;}
  private GradientDrawable glowShape(int radius){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(12,34,57),Color.rgb(4,12,24)});d.setCornerRadius(radius);d.setStroke(2,Color.rgb(0,154,235));return d;}
  private TextView smallCaps(String s){TextView t=text(s,10,CYAN,true);t.setLetterSpacing(.08f);return t;}
  private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);t.setIncludeFontPadding(false);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
  private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);return l;} private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
  private LinearLayout panel(int pad){LinearLayout l=col();l.setPadding(pad,pad,pad,pad);l.setBackground(shape(PANEL,BLUE,20));return l;}
  private void buildHome(){
    showingTrd=false;
    root=col();root.setPadding(dp(18),dp(5),dp(18),dp(8));root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(3,12,25),Color.rgb(1,5,13),Color.rgb(5,16,29)}));setContentView(root);
    LinearLayout top=row();top.setGravity(Gravity.CENTER_VERTICAL);root.addView(top,new LinearLayout.LayoutParams(-1,62));
    ImageView brand=new ImageView(this);brand.setScaleType(ImageView.ScaleType.FIT_START);
    try(InputStream brandStream=getAssets().open("brand_lockup.png")){brand.setImageBitmap(BitmapFactory.decodeStream(brandStream));}catch(Exception ignored){}
    top.addView(brand,new LinearLayout.LayoutParams(0,-1,1.0f));
    LinearLayout status=row();status.setGravity(Gravity.CENTER_VERTICAL);
    TextView bt=text("ᛒ",25,WHITE,true);status.addView(bt);
    TextView wifi=text("◢",24,WHITE,true);LinearLayout.LayoutParams wp=new LinearLayout.LayoutParams(-2,-1);wp.leftMargin=dp(12);status.addView(wifi,wp);
    clock=text("--:--",30,WHITE,true);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-2,-1);cp.leftMargin=dp(18);status.addView(clock,cp);
    top.addView(status,new LinearLayout.LayoutParams(-2,-1));
    date=text("",12,MUTED,false);date.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);root.addView(date,new LinearLayout.LayoutParams(-1,18));
    View line=new View(this);line.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{Color.TRANSPARENT,BLUE,Color.rgb(15,85,135),Color.TRANSPARENT}));root.addView(line,new LinearLayout.LayoutParams(-1,2));
    LinearLayout body=row();LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,0,1);bp.topMargin=10;bp.bottomMargin=10;root.addView(body,bp);
    LinearLayout center=col();center.setPadding(10,10,10,10);center.setBackground(glowShape(22));LinearLayout.LayoutParams cpar=new LinearLayout.LayoutParams(0,-1,2.45f);body.addView(center,cpar);
    FrameLayout hero=new FrameLayout(this);hero.setBackground(shape(Color.rgb(4,15,29),Color.rgb(18,90,145),18));center.addView(hero,new LinearLayout.LayoutParams(-1,-1));
    try{InputStream is=getAssets().open("avensis_hero.jpg");Bitmap bm=BitmapFactory.decodeStream(is);is.close();ImageView carImage=new ImageView(this);carImage.setImageBitmap(bm);carImage.setScaleType(ImageView.ScaleType.CENTER_CROP);hero.addView(carImage,new FrameLayout.LayoutParams(-1,-1));carImage.setAlpha(.94f);}catch(Exception ignored){}
    View shade=new View(this);shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0x66020A16,0x00000000,0xCC020914}));hero.addView(shade,new FrameLayout.LayoutParams(-1,-1));
    LinearLayout heroText=col();heroText.setPadding(20,14,20,16);FrameLayout.LayoutParams htp=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM|Gravity.LEFT);hero.addView(heroText,htp);
    TextView welcome=text("ПРИВЕТСТВУЮ, ДАНИИЛ",18,CYAN,true);welcome.setLetterSpacing(.12f);heroText.addView(welcome);
    TextView plate=text("AVENSIS T25     •     А363НА252",15,WHITE,true);plate.setShadowLayer(8,0,0,Color.BLACK);heroText.addView(plate);
    LinearLayout right=col();right.setPadding(14,14,14,14);right.setBackground(glowShape(20));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,-1,1);rp.leftMargin=10;body.addView(right,rp);
    TextView bc=smallCaps("БОРТОВОЙ КОМПЬЮТЕР");bc.setTextSize(14);right.addView(bc);right.addView(text("ДАННЫЕ АВТОМОБИЛЯ",12,MUTED,false));
    metric(right,"ТЕМПЕРАТУРА ОЖ",()->coolant<0?"—":coolant+" °C");
    metric(right,"СКОРОСТЬ",()->speed<0?"—":speed+" км/ч");
    metric(right,"ОБОРОТЫ ДВИГАТЕЛЯ",()->rpm<0?"—":rpm+" об/мин");
    obdState=text(obdMessage,9,obdRunning?CYAN:MUTED,true);right.addView(obdState);
    obdConnect=text(obdRunning?"ОТКЛЮЧИТЬ OBD2":"ПОДКЛЮЧИТЬ OBD2",11,WHITE,true);obdConnect.setGravity(Gravity.CENTER);obdConnect.setBackground(glowShape(12));LinearLayout.LayoutParams c=new LinearLayout.LayoutParams(-1,38);c.topMargin=7;right.addView(obdConnect,c);obdConnect.setOnClickListener(v->{if(obdRunning)disconnectObd();else chooseObd();});
    LinearLayout dock=row();dock.setGravity(Gravity.CENTER_VERTICAL);root.addView(dock,new LinearLayout.LayoutParams(-1,dp(88)));for(int i=0;i<slots.length;i++)addTile(dock,i);
  }
  private interface Value {String get();}
  private void metric(LinearLayout p,String name,Value v){LinearLayout m=col();m.setPadding(9,7,9,7);m.setBackground(shape(Color.rgb(5,15,27),Color.rgb(18,65,102),9));LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(-1,0,1);q.topMargin=5;p.addView(m,q);m.addView(text(name,11,MUTED,true));TextView val=text(v.get(),22,WHITE,true);m.addView(val);ui.postDelayed(new Runnable(){public void run(){if(!isFinishing()&&val.getWindowToken()!=null){val.setText(v.get());ui.postDelayed(this,700);}}},700);}
  private void addTile(LinearLayout dock,int i){
    LinearLayout tile=col();tile.setGravity(Gravity.CENTER);tile.setPadding(dp(5),dp(5),dp(5),dp(4));
    tile.setBackground(new PremiumTileDrawable());tile.setElevation(dp(8));
    if(Build.VERSION.SDK_INT>=21)tile.setForeground(ripple(Color.WHITE));
    LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);if(i>0)p.leftMargin=dp(6);dock.addView(tile,p);
    String saved=getPreferences(0).getString("slot_icon_"+i,defaultIcons[i]);
    if(saved.equals(defaultIcons[i])){
      ImageView icon=new ImageView(this);icon.setScaleType(ImageView.ScaleType.FIT_CENTER);icon.setAdjustViewBounds(true);
      String[] files={"nav","music","phone","radio","video","apps","trd","settings"};
      try(InputStream iconStream=getAssets().open("icons/"+files[i]+".png")){icon.setImageBitmap(BitmapFactory.decodeStream(iconStream));}catch(Exception ignored){}
      LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,0,1.0f);ip.bottomMargin=dp(3);tile.addView(icon,ip);
    }else{
      TextView custom=text(saved,30,i==6?WHITE:CYAN,true);custom.setGravity(Gravity.CENTER);tile.addView(custom,new LinearLayout.LayoutParams(-1,0,1.0f));
    }
    TextView name=text(getSlotName(i),12,WHITE,true);name.setGravity(Gravity.CENTER);name.setSingleLine(true);name.setTextScaleX(.96f);name.setShadowLayer(5,0,1,Color.rgb(0,80,145));
    tile.addView(name,new LinearLayout.LayoutParams(-1,dp(23)));
    tile.setOnClickListener(v->onSlot(i));tile.setOnLongClickListener(v->{showTileOptions(i);return true;});
  }
  private class PremiumTileDrawable extends android.graphics.drawable.Drawable{
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    @Override public void draw(Canvas canvas){
      Rect b=getBounds();
      float l=b.left+1.5f,t=b.top+1.5f,r=b.right-1.5f,bt=b.bottom-1.5f;
      float rad=dp(15);
      // Deep glass body: one outer edge only. The former inset stroke created
      // the unwanted pair of blue "stripes" around every tile.
      paint.setStyle(Paint.Style.FILL);
      paint.setShader(new LinearGradient(l,t,l,bt,
          new int[]{Color.rgb(22,47,73),Color.rgb(10,25,44),Color.rgb(3,10,21)},
          new float[]{0f,.48f,1f},Shader.TileMode.CLAMP));
      canvas.drawRoundRect(l,t,r,bt,rad,rad,paint);paint.setShader(null);

      // Subtle diagonal glass reflection, clipped to the card silhouette.
      int save=canvas.save();
      Path clip=new Path();clip.addRoundRect(l+1,t+1,r-1,bt-1,rad-1,rad-1,Path.Direction.CW);
      canvas.clipPath(clip);
      paint.setStyle(Paint.Style.FILL);
      paint.setShader(new LinearGradient(l,t,r,bt,
          new int[]{0x263B9BCB,0x103B9BCB,0x003B9BCB},
          new float[]{0f,.34f,1f},Shader.TileMode.CLAMP));
      Path sheen=new Path();sheen.moveTo(l,t);sheen.lineTo(l+dp(46),t);sheen.lineTo(r,t+dp(48));
      sheen.lineTo(r,t+dp(77));sheen.close();canvas.drawPath(sheen,paint);paint.setShader(null);
      // Soft top inner reflection without a second rectangular border.
      paint.setShader(new LinearGradient(l,t,l,t+dp(38),
          new int[]{0x383F9BCB,0x123F9BCB,0x003F9BCB},null,Shader.TileMode.CLAMP));
      canvas.drawRoundRect(l+dp(3),t+dp(2),r-dp(3),t+dp(42),rad,rad,paint);paint.setShader(null);
      canvas.restoreToCount(save);

      // Single cyan rim with a soft blue bloom.
      paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(1.35f));
      paint.setColor(Color.rgb(63,181,255));paint.setShadowLayer(dp(8),0,0,Color.rgb(0,133,255));
      canvas.drawRoundRect(l,t,r,bt,rad,rad,paint);paint.clearShadowLayer();

      // A short light catch on the lower edge, matching the reference tiles.
      paint.setStyle(Paint.Style.FILL);
      paint.setShader(new LinearGradient(l,bt-dp(2),r,bt-dp(2),
          new int[]{0x003CBFFF,0xCC45C8FF,0x003CBFFF},null,Shader.TileMode.CLAMP));
      canvas.drawRoundRect(l+dp(18),bt-dp(2.5f),r-dp(18),bt-dp(.5f),dp(2),dp(2),paint);
      paint.setShader(null);paint.setStyle(Paint.Style.FILL);
    }
    @Override public void setAlpha(int a){}@Override public void setColorFilter(android.graphics.ColorFilter f){}@Override public int getOpacity(){return android.graphics.PixelFormat.TRANSLUCENT;}
  }
  private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
  private android.graphics.drawable.Drawable ripple(int color){
    if(Build.VERSION.SDK_INT>=21){android.util.TypedValue tv=new android.util.TypedValue();getTheme().resolveAttribute(android.R.attr.selectableItemBackground,tv,true);return getDrawable(tv.resourceId);}return null;
  }
  private class IconView extends View {
    private final int kind; private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    IconView(int k){super(MainActivity.this);kind=k;setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
    private void stroke(Canvas c,int color,float width){paint.setColor(color);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(width);paint.setStrokeCap(Paint.Cap.ROUND);paint.setStrokeJoin(Paint.Join.ROUND);paint.setShadowLayer(12,0,0,color);}
    private void fill(int color){paint.setColor(color);paint.setStyle(Paint.Style.FILL);paint.clearShadowLayer();}
    @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);float w=getWidth(),h=getHeight(),cx=w/2f,cy=h/2f;float u=Math.min(w,h)*.34f;canvas.save();canvas.translate(cx-u,cy-u);canvas.scale((2*u)/100f,(2*u)/100f);
      int blue=Color.rgb(39,174,255),cyan=Color.rgb(74,221,255),white=Color.rgb(226,241,255);
      switch(kind){
      case 0: // navigation arrow
        Path nav=new Path();nav.moveTo(8,8);nav.lineTo(91,43);nav.lineTo(55,54);nav.lineTo(39,91);nav.close();fill(blue);paint.setShadowLayer(13,0,0,blue);canvas.drawPath(nav,paint);fill(cyan);Path cut=new Path();cut.moveTo(39,91);cut.lineTo(55,54);cut.lineTo(91,43);cut.close();canvas.drawPath(cut,paint);break;
      case 1: // music note
        stroke(canvas,blue,10);Path note=new Path();note.moveTo(62,15);note.lineTo(62,68);note.cubicTo(62,83,42,90,32,80);note.cubicTo(20,68,35,55,53,59);note.lineTo(53,15);note.close();paint.setStyle(Paint.Style.FILL);canvas.drawPath(note,paint);canvas.drawLine(62,15,88,8,paint);canvas.drawLine(88,8,88,58,paint);canvas.drawCircle(72,70,12,paint);break;
      case 2: // handset
        fill(Color.rgb(48,213,105));Path phone=new Path();phone.moveTo(27,9);phone.cubicTo(17,11,9,24,13,39);phone.cubicTo(24,72,48,91,76,91);phone.cubicTo(89,91,96,77,89,69);phone.lineTo(70,57);phone.lineTo(57,70);phone.cubicTo(42,63,34,54,29,39);phone.lineTo(42,27);phone.close();paint.setShadowLayer(12,0,0,Color.rgb(30,210,90));canvas.drawPath(phone,paint);break;
      case 3: // radio
        stroke(canvas,white,6);canvas.drawRoundRect(13,27,88,84,9,9,paint);canvas.drawLine(18,19,77,6,paint);canvas.drawLine(24,44,78,44,paint);canvas.drawCircle(35,64,10,paint);canvas.drawCircle(69,64,10,paint);stroke(canvas,blue,4);canvas.drawLine(25,14,12,5,paint);break;
      case 4: // play
        Path play=new Path();play.moveTo(27,10);play.lineTo(86,50);play.lineTo(27,90);play.close();fill(Color.rgb(160,126,255));paint.setShadowLayer(14,0,0,Color.rgb(120,100,255));canvas.drawPath(play,paint);break;
      case 5: // apps grid
        fill(white);for(int y=0;y<3;y++)for(int x=0;x<3;x++)canvas.drawRoundRect(12+x*29,12+y*29,32+x*29,32+y*29,6,6,paint);break;
      case 6: // TRD tachometer / racing mark
        stroke(canvas,cyan,8);canvas.drawArc(12,14,88,90,190,160,false,paint);canvas.drawLine(50,51,75,28,paint);fill(white);canvas.drawCircle(50,51,6,paint);paint.setTextAlign(Paint.Align.CENTER);paint.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD));paint.setTextSize(22);canvas.drawText("TRD",50,99,paint);break;
      case 7: // gear
        fill(white);canvas.drawCircle(50,50,23,paint);for(int j=0;j<8;j++){canvas.save();canvas.rotate(j*45,50,50);canvas.drawRoundRect(43,4,57,28,3,3,paint);canvas.restore();}fill(Color.rgb(12,27,46));canvas.drawCircle(50,50,10,paint);break;
      }
      canvas.restore();
    }
  }
  private String getSlotName(int i){return getPreferences(0).getString("slot_label_"+i,slots[i]);}
  private String getSlotPackage(int i){return getPreferences(0).getString("slot_pkg_"+i,defaults[i]);}
  private void onSlot(int i){if(i==6){showTrd();return;}if(i==5){showApps();return;}if(i==7){startActivity(new Intent(Settings.ACTION_SETTINGS));return;}String pkg=getSlotPackage(i);if(pkg.isEmpty()){chooseAppForSlot(i);return;}launchPackage(pkg);}
  private void launchPackage(String pkg){try{Intent in=getPackageManager().getLaunchIntentForPackage(pkg);if(in==null){Toast.makeText(this,"Приложение не найдено",Toast.LENGTH_SHORT).show();return;}startActivity(in);}catch(Exception e){Toast.makeText(this,"Не удалось открыть приложение",Toast.LENGTH_SHORT).show();}}
  private void showTileOptions(int slot){new AlertDialog.Builder(this).setTitle("Настроить плитку: "+getSlotName(slot)).setItems(new String[]{"Выбрать приложение","Изменить значок","Сбросить плитку"},(d,w)->{if(w==0)chooseAppForSlot(slot);else if(w==1)chooseIconForSlot(slot);else{getPreferences(0).edit().remove("slot_pkg_"+slot).remove("slot_label_"+slot).remove("slot_icon_"+slot).apply();buildHome();}}).setNegativeButton("Отмена",null).show();}
  private void chooseIconForSlot(int slot){new AlertDialog.Builder(this).setTitle("Значок плитки").setItems(iconChoices,(d,w)->{getPreferences(0).edit().putString("slot_icon_"+slot,iconChoices[w]).apply();buildHome();}).setNegativeButton("Отмена",null).show();}
  private void chooseAppForSlot(int slot){Intent q=new Intent(Intent.ACTION_MAIN);q.addCategory(Intent.CATEGORY_LAUNCHER);PackageManager pm=getPackageManager();List<ResolveInfo> list=pm.queryIntentActivities(q,0);Collections.sort(list,(a,b)->String.valueOf(a.loadLabel(pm)).compareToIgnoreCase(String.valueOf(b.loadLabel(pm))));String[] labels=new String[list.size()];for(int i=0;i<list.size();i++)labels[i]=String.valueOf(list.get(i).loadLabel(pm));new AlertDialog.Builder(this).setTitle("Выбрать приложение: "+getSlotName(slot)).setItems(labels,(d,w)->{ResolveInfo r=list.get(w);getPreferences(0).edit().putString("slot_pkg_"+slot,r.activityInfo.packageName).putString("slot_label_"+slot,labels[w]).apply();Toast.makeText(this,"Ярлык обновлён",Toast.LENGTH_SHORT).show();buildHome();}).setNegativeButton("Отмена",null).show();}
  private void showApps(){Intent q=new Intent(Intent.ACTION_MAIN);q.addCategory(Intent.CATEGORY_LAUNCHER);PackageManager pm=getPackageManager();List<ResolveInfo> a=pm.queryIntentActivities(q,0);Collections.sort(a,(x,y)->String.valueOf(x.loadLabel(pm)).compareToIgnoreCase(String.valueOf(y.loadLabel(pm))));String[] n=new String[a.size()];for(int i=0;i<a.size();i++)n[i]=String.valueOf(a.get(i).loadLabel(pm));new AlertDialog.Builder(this).setTitle("Приложения").setItems(n,(d,w)->launchPackage(a.get(w).activityInfo.packageName)).setNegativeButton("Закрыть",null).show();}
  private void showTrd(){
    showingTrd=true;LinearLayout page=col();trdPage=page;page.setPadding(18,12,18,12);page.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(2,8,17),Color.rgb(4,16,30),Color.rgb(1,5,12)}));page.setTranslationY(getResources().getDisplayMetrics().heightPixels);setContentView(page);
    LinearLayout head=row();head.setGravity(Gravity.CENTER_VERTICAL);page.addView(head,new LinearLayout.LayoutParams(-1,48));TextView title=text("TRD",28,WHITE,true);title.setLetterSpacing(.14f);head.addView(title,new LinearLayout.LayoutParams(0,-1,1));TextView sub=text("RACE MODE  /  1ZZ-FE",12,CYAN,true);head.addView(sub);TextView back=text("  ←  НАЗАД  ",13,WHITE,true);back.setGravity(Gravity.CENTER);back.setBackground(glowShape(12));LinearLayout.LayoutParams backp=new LinearLayout.LayoutParams(-2,38);backp.leftMargin=14;head.addView(back,backp);back.setOnClickListener(v->closeTrd(page));
    View separator=new View(this);separator.setBackgroundColor(Color.rgb(0,135,210));page.addView(separator,new LinearLayout.LayoutParams(-1,2));
    LinearLayout gauges=row();gauges.setGravity(Gravity.CENTER);LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,0,1);gp.topMargin=8;gp.bottomMargin=8;page.addView(gauges,gp);rpmGauge=new GaugeView(true);speedGauge=new GaugeView(false);gauges.addView(rpmGauge,new LinearLayout.LayoutParams(0,-1,1));gauges.addView(speedGauge,new LinearLayout.LayoutParams(0,-1,1));
    LinearLayout stats=col();stats.setPadding(8,8,8,8);stats.setBackground(glowShape(17));page.addView(stats,new LinearLayout.LayoutParams(-1,116));LinearLayout s1=row();stats.addView(s1,new LinearLayout.LayoutParams(-1,0,1));addStat(s1,"ТЕМП. ОЖ",()->coolant<0?"—":coolant+" °C");addStat(s1,"ТЕМП. ВПУСКА",()->intake<0?"—":intake+" °C");addStat(s1,"НАГРУЗКА",()->load<0?"—":load+" %");addStat(s1,"ДРОССЕЛЬ",()->throttle<0?"—":throttle+" %");LinearLayout s2=row();stats.addView(s2,new LinearLayout.LayoutParams(-1,0,1));addStat(s2,"ДАВЛЕНИЕ ВПУСКА",()->manifold<0?"—":manifold+" кПа");addStat(s2,"MAF",()->maf<0?"—":String.format(Locale.US,"%.1f г/с",maf));addStat(s2,"УГОЛ ЗАЖИГАНИЯ",()->timing<0?"—":timing+"°");addStat(s2,"АТМОСФЕРА",()->barometric<0?"—":barometric+" кПа");
    obdState=text(obdMessage,11,obdRunning?CYAN:MUTED,true);obdState.setGravity(Gravity.CENTER);page.addView(obdState,new LinearLayout.LayoutParams(-1,25));obdConnect=text(obdRunning?"ОТКЛЮЧИТЬ OBD2":"ПОДКЛЮЧИТЬ BLUETOOTH ELM327",13,WHITE,true);obdConnect.setGravity(Gravity.CENTER);obdConnect.setBackground(glowShape(12));page.addView(obdConnect,new LinearLayout.LayoutParams(-1,40));obdConnect.setOnClickListener(v->{if(obdRunning)disconnectObd();else chooseObd();});page.post(()->page.animate().translationY(0).setDuration(380).setInterpolator(new android.view.animation.DecelerateInterpolator()).start());ui.post(new Runnable(){public void run(){if(showingTrd&&rpmGauge!=null&&speedGauge!=null){rpmGauge.invalidate();speedGauge.invalidate();ui.postDelayed(this,250);}}});
  }
  private void closeTrd(View page){
    if(!showingTrd)return;showingTrd=false;
    page.animate().translationY(getResources().getDisplayMetrics().heightPixels).setDuration(300).setInterpolator(new android.view.animation.AccelerateInterpolator()).withEndAction(()->{rpmGauge=null;speedGauge=null;buildHome();}).start();
  }
  private void addStat(LinearLayout p,String label,Value value){LinearLayout c=col();c.setGravity(Gravity.CENTER);p.addView(c,new LinearLayout.LayoutParams(0,-1,1));c.addView(text(label,9,CYAN,true));TextView val=text(value.get(),16,WHITE,true);c.addView(val);ui.postDelayed(new Runnable(){public void run(){if(!isFinishing()&&showingTrd&&val.getWindowToken()!=null){val.setText(value.get());ui.postDelayed(this,500);}}},500);}
  private class GaugeView extends View{boolean isRpm;Paint p=new Paint(3);GaugeView(boolean r){super(MainActivity.this);isRpm=r;setLayerType(View.LAYER_TYPE_SOFTWARE,null);}protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),cx=w/2,cy=h*.53f,r=Math.min(w*.37f,h*.39f);p.setStyle(Paint.Style.STROKE);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeWidth(22);p.setColor(Color.rgb(13,31,49));c.drawArc(cx-r,cy-r,cx+r,cy+r,135,270,false,p);p.setShadowLayer(16,0,0,BLUE);p.setStrokeWidth(5);p.setColor(CYAN);float progress=isRpm?(rpm<0?0:Math.min(1,rpm/7000f)):(speed<0?0:Math.min(1,speed/240f));c.drawArc(cx-r,cy-r,cx+r,cy+r,135,270*progress,false,p);p.clearShadowLayer();p.setStrokeWidth(3);for(int i=0;i<=14;i++){double a=Math.toRadians(135+i*(270.0/14));float x1=cx+(float)Math.cos(a)*(r-15),y1=cy+(float)Math.sin(a)*(r-15),x2=cx+(float)Math.cos(a)*(r+3),y2=cy+(float)Math.sin(a)*(r+3);p.setColor(i>=12&&isRpm?Color.rgb(255,70,75):WHITE);c.drawLine(x1,y1,x2,y2,p);}p.setStyle(Paint.Style.FILL);p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(Math.min(w*.17f,62));p.setColor(WHITE);String number=isRpm?(rpm<0?"—":String.valueOf(rpm)):(speed<0?"—":String.valueOf(speed));c.drawText(number,cx,cy+15,p);p.setTextSize(17);p.setColor(CYAN);c.drawText(isRpm?"RPM":"КМ/Ч",cx,cy+43,p);p.setTextSize(12);p.setColor(MUTED);c.drawText(isRpm?"0          7 000":"0           240",cx,cy+r*.68f,p);p.setTextSize(11);p.setColor(WHITE);c.drawText(isRpm?"1ZZ-FE  /  ENGINE":"AVENSIS  /  ROAD SPEED",cx,cy+r+32,p);}}
  private void chooseObd(){if(Build.VERSION.SDK_INT>=31&&checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},44);return;}try{BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();if(a==null){toast("Bluetooth недоступен");return;}if(!a.isEnabled()){toast("Включи Bluetooth в настройках магнитолы");startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));return;}Set<BluetoothDevice> devices=a.getBondedDevices();ArrayList<BluetoothDevice> obd=new ArrayList<>();for(BluetoothDevice d:devices)obd.add(d);if(obd.isEmpty()){toast("Сначала сопряги ELM327 в настройках Bluetooth Android");return;}String[] names=new String[obd.size()];for(int i=0;i<obd.size();i++)names[i]=obd.get(i).getName()+"\n"+obd.get(i).getAddress();new AlertDialog.Builder(this).setTitle("Выбрать Bluetooth OBD2").setItems(names,(d,w)->connectObd(obd.get(w))).setNegativeButton("Отмена",null).show();}catch(SecurityException e){toast("Нет разрешения Bluetooth");}}
  @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==44&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)chooseObd();else if(r==44)toast("Для Bluetooth OBD2 необходимо разрешение Bluetooth");}
  private void connectObd(BluetoothDevice device){disconnectObd();final int generation=++obdGeneration;obdMessage="ПОДКЛЮЧЕНИЕ К "+safeDeviceName(device);updateObdText();obdRunning=true;obdThread=new Thread(()->{BluetoothSocket local=null;try{try{local=device.createRfcommSocketToServiceRecord(SPP);socket=local;local.connect();}catch(IOException secureError){if(generation!=obdGeneration||!obdRunning)return;try{if(local!=null)local.close();}catch(Exception ignored){}local=device.createInsecureRfcommSocketToServiceRecord(SPP);socket=local;local.connect();}if(generation!=obdGeneration||!obdRunning)return;InputStream in=local.getInputStream();OutputStream out=local.getOutputStream();send(in,out,"ATZ");send(in,out,"ATE0");send(in,out,"ATL0");send(in,out,"ATS0");send(in,out,"ATH0");send(in,out,"ATSP0");send(in,out,"ATST64");obdMessage="OBD2 ПОДКЛЮЧЁН · "+safeDeviceName(device);postGauges();long nextDetails=0;while(obdRunning&&generation==obdGeneration&&!Thread.currentThread().isInterrupted()&&local.isConnected()){rpm=parseRpm(send(in,out,"010C"));speed=parseSpeed(send(in,out,"010D"));long now=System.currentTimeMillis();if(now>=nextDetails){coolant=parseTemp(send(in,out,"0105"));intake=parseTemp(send(in,out,"010F"));load=parsePercent(send(in,out,"0104"),"04");throttle=parsePercent(send(in,out,"0111"),"11");manifold=parseSingle(send(in,out,"010B"),"0B");maf=parseMaf(send(in,out,"0110"));timing=parseTiming(send(in,out,"010E"));barometric=parseSingle(send(in,out,"0133"),"33");nextDetails=System.currentTimeMillis()+3000;}postGauges();Thread.sleep(120);}}catch(Exception e){if(obdRunning)obdMessage="ОШИБКА OBD2: "+e.getClass().getSimpleName();}finally{try{if(local!=null)local.close();}catch(Exception ignored){}if(socket==local)socket=null;if(generation==obdGeneration){obdRunning=false;updateObdText();}}});obdThread.start();updateObdText();}
  private String safeDeviceName(BluetoothDevice d){try{return d.getName()==null?d.getAddress():d.getName();}catch(SecurityException e){return "ELM327";}}
  private String send(InputStream in,OutputStream out,String cmd)throws Exception{while(in.available()>0)in.read();out.write((cmd+"\r").getBytes(StandardCharsets.US_ASCII));out.flush();ByteArrayOutputStream b=new ByteArrayOutputStream();long end=System.currentTimeMillis()+900;while(System.currentTimeMillis()<end){if(in.available()>0){int x=in.read();if(x=='>')break;b.write(x);}else Thread.sleep(15);}return b.toString("US-ASCII").replace("\r","").replace("\n","").replace(" ","").toUpperCase(Locale.US);}
  private int[] payload(String s,String pid){Matcher m=Pattern.compile("41"+pid+"([0-9A-F]{2,})").matcher(s);if(!m.find())return null;String x=m.group(1);int[] a=new int[x.length()/2];for(int i=0;i<a.length;i++)a[i]=Integer.parseInt(x.substring(i*2,i*2+2),16);return a;}
  private int parseRpm(String s){int[] a=payload(s,"0C");return a==null||a.length<2?-1:((a[0]*256+a[1])/4);}private int parseTiming(String s){int[] a=payload(s,"0E");return a==null?-1:Math.round(a[0]/2f)-64;}private int parseSpeed(String s){int[] a=payload(s,"0D");return a==null?-1:a[0];}private int parseTemp(String s){int[] a=payload(s,"05");return a==null?-1:a[0]-40;}private int parsePercent(String s,String pid){int[] a=payload(s,pid);return a==null?-1:Math.round(a[0]*100f/255f);}private int parseSingle(String s,String pid){int[] a=payload(s,pid);return a==null?-1:a[0];}private double parseMaf(String s){int[] a=payload(s,"10");return a==null||a.length<2?-1:(a[0]*256+a[1])/100.0;}
  private void postGauges(){ui.post(()->{if(rpmGauge!=null)rpmGauge.invalidate();if(speedGauge!=null)speedGauge.invalidate();updateObdText();});}private void updateObdText(){ui.post(()->{if(obdState!=null)obdState.setText(obdMessage);if(obdConnect!=null)obdConnect.setText(obdRunning?"ОТКЛЮЧИТЬ OBD2":"ПОДКЛЮЧИТЬ / ВЫБРАТЬ OBD2");});}
  private void disconnectObd(){obdGeneration++;obdRunning=false;if(obdThread!=null)obdThread.interrupt();try{if(socket!=null)socket.close();}catch(Exception ignored){}socket=null;rpm=speed=coolant=intake=load=throttle=manifold=timing=barometric=-1;maf=-1;obdMessage="OBD2 НЕ ПОДКЛЮЧЁН";updateObdText();}

  private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
