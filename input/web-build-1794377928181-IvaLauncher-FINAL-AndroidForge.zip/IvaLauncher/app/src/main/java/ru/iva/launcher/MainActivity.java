package ru.iva.launcher;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.*;

public class MainActivity extends Activity {
  private static final int BG=Color.rgb(3,9,18), PANEL=Color.rgb(7,19,34), BLUE=Color.rgb(0,166,255), WHITE=Color.rgb(235,245,255), MUTED=Color.rgb(135,160,185);
  private static final UUID SPP=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
  private final Handler ui=new Handler(); private boolean showingTrd=false; private LinearLayout root,trdPage; private TextView clock,date,obdState,obdConnect; private GaugeView rpmGauge,speedGauge; private final String[] slots={"Навигация","Музыка","Телефон","Радио","Видео","Приложения","TRD","Настройки"};
  private final String[] actions={"maps","music","phone","radio","video","apps","trd","settings"};
  private final String[] defaults={"ru.yandex.yandexmaps","com.android.music","com.android.dialer","com.syu.radio","com.google.android.youtube","","",""};
  private final String[] defaultIcons={"➤","♫","☎","▣","▶","▦","TRD","⚙"};
  private final String[] iconChoices={"➤","♫","☎","▣","▶","▦","TRD","⚙","★","♥","☀","☾","✉","◎","◉","◆","●","＋"};
  private BluetoothSocket socket; private volatile int obdGeneration=0; private volatile boolean obdRunning=false; private Thread obdThread; private volatile int rpm=-1,speed=-1,coolant=-1,intake=-1,load=-1,throttle=-1,manifold=-1,timing=-1,barometric=-1; private volatile double maf=-1; private volatile String obdMessage="OBD2 НЕ ПОДКЛЮЧЁН";
  private final Runnable tick=()->{ if(clock!=null)clock.setText(new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date())); if(date!=null)date.setText(new SimpleDateFormat("EEEE, d MMMM",new Locale("ru")).format(new Date())); ui.postDelayed(this.tick,15000); };
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);buildHome();tick.run();}
  @Override protected void onDestroy(){ui.removeCallbacks(tick);disconnectObd();super.onDestroy();}
  @Override public void onBackPressed(){if(showingTrd){closeTrd(trdPage);}else{super.onBackPressed();}}
  private GradientDrawable shape(int color,int stroke,int radius){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{color,Color.rgb(4,13,25)});d.setCornerRadius(radius);d.setStroke(2,stroke);return d;}
  private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);t.setIncludeFontPadding(false);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
  private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);return l;} private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
  private LinearLayout panel(int pad){LinearLayout l=col();l.setPadding(pad,pad,pad,pad);l.setBackground(shape(PANEL,BLUE,20));return l;}
  private void buildHome(){
    showingTrd=false;
    root=col();root.setPadding(18,8,18,10);root.setBackgroundColor(BG);setContentView(root);
    LinearLayout top=row();top.setGravity(Gravity.CENTER_VERTICAL);root.addView(top,new LinearLayout.LayoutParams(-1,48));
    TextView brand=text("AVENSIS",25,WHITE,true);top.addView(brand,new LinearLayout.LayoutParams(0,-1,1));
    TextView bt=text("ᛒ   Wi-Fi",15,BLUE,true);top.addView(bt);clock=text("--:--",28,WHITE,true);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-2,-1);cp.leftMargin=20;top.addView(clock,cp);
    date=text("",13,MUTED,false);date.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);root.addView(date,new LinearLayout.LayoutParams(-1,22));
    LinearLayout body=row();LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,0,1);bp.topMargin=8;bp.bottomMargin=10;root.addView(body,bp);
    LinearLayout center=col();center.setPadding(16,10,16,8);center.setBackground(shape(PANEL,Color.rgb(20,105,165),18));body.addView(center,new LinearLayout.LayoutParams(0,-1,2.3f));
    TextView greeting=text("Приветствую, Даниил",22,BLUE,true);center.addView(greeting,new LinearLayout.LayoutParams(-1,34));
    TextView car=text("А363НА252",13,MUTED,true);center.addView(car,new LinearLayout.LayoutParams(-1,25));
    TextView visual=text("AVENSIS T25\nСЕРЕБРИСТЫЙ КУЗОВ\n\nИзображение автомобиля добавляется в проект отдельным ресурсом",17,WHITE,true);visual.setGravity(Gravity.CENTER);visual.setBackground(shape(Color.rgb(5,16,29),Color.rgb(17,77,120),16));LinearLayout.LayoutParams vp=new LinearLayout.LayoutParams(-1,0,1);vp.topMargin=6;vp.bottomMargin=6;center.addView(visual,vp);
    LinearLayout right=panel(12);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,-1,1);rp.leftMargin=10;body.addView(right,rp);right.addView(text("БОРТОВОЙ КОМПЬЮТЕР",14,BLUE,true));right.addView(text("Краткие поездочные данные",10,MUTED,false));
    metric(right,"ЗАПАС ХОДА",()->"—");
    metric(right,"ТЕМПЕРАТУРА ОЖ",()->coolant<0?"—":coolant+" °C");
    metric(right,"СКОРОСТЬ",()->speed<0?"—":speed+" км/ч");
    obdState=text(obdMessage,9,MUTED,true);right.addView(obdState);obdConnect=text(obdRunning?"ОТКЛЮЧИТЬ OBD2":"ПОДКЛЮЧИТЬ OBD2",11,WHITE,true);obdConnect.setGravity(Gravity.CENTER);obdConnect.setBackground(shape(Color.rgb(5,37,62),BLUE,10));LinearLayout.LayoutParams c=new LinearLayout.LayoutParams(-1,36);c.topMargin=6;right.addView(obdConnect,c);obdConnect.setOnClickListener(v->{if(obdRunning)disconnectObd();else chooseObd();});
    LinearLayout dock=row();dock.setGravity(Gravity.CENTER_VERTICAL);root.addView(dock,new LinearLayout.LayoutParams(-1,102));for(int i=0;i<slots.length;i++)addTile(dock,i);
  }
  private interface Value {String get();}
  private void metric(LinearLayout p,String name,Value v){LinearLayout m=col();m.setPadding(7,5,7,5);m.setBackground(shape(Color.rgb(5,15,27),Color.rgb(18,65,102),9));LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(-1,0,1);q.topMargin=5;p.addView(m,q);m.addView(text(name,9,MUTED,true));TextView val=text(v.get(),17,WHITE,true);m.addView(val);ui.postDelayed(new Runnable(){public void run(){if(!isFinishing()&&val.getWindowToken()!=null){val.setText(v.get());ui.postDelayed(this,700);}}},700);}
  private void addTile(LinearLayout dock,int i){LinearLayout tile=col();tile.setGravity(Gravity.CENTER);tile.setPadding(2,4,2,3);tile.setBackground(shape(PANEL,BLUE,13));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);if(i>0)p.leftMargin=6;dock.addView(tile,p);String icon=getPreferences(0).getString("slot_icon_"+i,defaultIcons[i]);TextView ic=text(icon,i==6?20:25,BLUE,true);ic.setGravity(Gravity.CENTER);tile.addView(ic,new LinearLayout.LayoutParams(-1,45));TextView name=text(getSlotName(i),9,WHITE,true);name.setGravity(Gravity.CENTER);tile.addView(name,new LinearLayout.LayoutParams(-1,25));tile.setOnClickListener(v->onSlot(i));tile.setOnLongClickListener(v->{showTileOptions(i);return true;});}
  private String getSlotName(int i){return getPreferences(0).getString("slot_label_"+i,slots[i]);}
  private String getSlotPackage(int i){return getPreferences(0).getString("slot_pkg_"+i,defaults[i]);}
  private void onSlot(int i){if(i==6){showTrd();return;}if(i==5){showApps();return;}if(i==7){startActivity(new Intent(Settings.ACTION_SETTINGS));return;}String pkg=getSlotPackage(i);if(pkg.isEmpty()){chooseAppForSlot(i);return;}launchPackage(pkg);}
  private void launchPackage(String pkg){try{Intent in=getPackageManager().getLaunchIntentForPackage(pkg);if(in==null){Toast.makeText(this,"Приложение не найдено",Toast.LENGTH_SHORT).show();return;}startActivity(in);}catch(Exception e){Toast.makeText(this,"Не удалось открыть приложение",Toast.LENGTH_SHORT).show();}}
  private void showTileOptions(int slot){new AlertDialog.Builder(this).setTitle("Настроить плитку: "+getSlotName(slot)).setItems(new String[]{"Выбрать приложение","Изменить значок","Сбросить плитку"},(d,w)->{if(w==0)chooseAppForSlot(slot);else if(w==1)chooseIconForSlot(slot);else{getPreferences(0).edit().remove("slot_pkg_"+slot).remove("slot_label_"+slot).remove("slot_icon_"+slot).apply();buildHome();}}).setNegativeButton("Отмена",null).show();}
  private void chooseIconForSlot(int slot){new AlertDialog.Builder(this).setTitle("Значок плитки").setItems(iconChoices,(d,w)->{getPreferences(0).edit().putString("slot_icon_"+slot,iconChoices[w]).apply();buildHome();}).setNegativeButton("Отмена",null).show();}
  private void chooseAppForSlot(int slot){Intent q=new Intent(Intent.ACTION_MAIN);q.addCategory(Intent.CATEGORY_LAUNCHER);PackageManager pm=getPackageManager();List<ResolveInfo> list=pm.queryIntentActivities(q,0);Collections.sort(list,(a,b)->String.valueOf(a.loadLabel(pm)).compareToIgnoreCase(String.valueOf(b.loadLabel(pm))));String[] labels=new String[list.size()];for(int i=0;i<list.size();i++)labels[i]=String.valueOf(list.get(i).loadLabel(pm));new AlertDialog.Builder(this).setTitle("Выбрать приложение: "+getSlotName(slot)).setItems(labels,(d,w)->{ResolveInfo r=list.get(w);getPreferences(0).edit().putString("slot_pkg_"+slot,r.activityInfo.packageName).putString("slot_label_"+slot,labels[w]).apply();Toast.makeText(this,"Ярлык обновлён",Toast.LENGTH_SHORT).show();buildHome();}).setNegativeButton("Отмена",null).show();}
  private void showApps(){Intent q=new Intent(Intent.ACTION_MAIN);q.addCategory(Intent.CATEGORY_LAUNCHER);PackageManager pm=getPackageManager();List<ResolveInfo> a=pm.queryIntentActivities(q,0);Collections.sort(a,(x,y)->String.valueOf(x.loadLabel(pm)).compareToIgnoreCase(String.valueOf(y.loadLabel(pm))));String[] n=new String[a.size()];for(int i=0;i<a.size();i++)n[i]=String.valueOf(a.get(i).loadLabel(pm));new AlertDialog.Builder(this).setTitle("Приложения").setItems(n,(d,w)->launchPackage(a.get(w).activityInfo.packageName)).setNegativeButton("Закрыть",null).show();}
  private void showTrd(){
    showingTrd=true;
    LinearLayout page=col();trdPage=page;page.setPadding(18,12,18,12);page.setBackgroundColor(BG);
    page.setTranslationY(getResources().getDisplayMetrics().heightPixels);
    setContentView(page);
    LinearLayout head=row();page.addView(head,new LinearLayout.LayoutParams(-1,48));
    TextView title=text("AVENSIS  /  TRD RACE MODE",23,BLUE,true);head.addView(title,new LinearLayout.LayoutParams(0,-1,1));
    TextView back=text("← НАЗАД",14,WHITE,true);head.addView(back);back.setOnClickListener(v->closeTrd(page));
    LinearLayout gauges=row();gauges.setGravity(Gravity.CENTER);page.addView(gauges,new LinearLayout.LayoutParams(-1,0,1));
    rpmGauge=new GaugeView(true);speedGauge=new GaugeView(false);
    gauges.addView(rpmGauge,new LinearLayout.LayoutParams(0,-1,1));gauges.addView(speedGauge,new LinearLayout.LayoutParams(0,-1,1));
    LinearLayout stats=row();stats.setBackground(shape(PANEL,BLUE,14));page.addView(stats,new LinearLayout.LayoutParams(-1,76));
    addStat(stats,"ТЕМП. ОЖ",()->coolant<0?"—":coolant+" °C");
    addStat(stats,"ТЕМП. ВПУСКА",()->intake<0?"—":intake+" °C");
    addStat(stats,"НАГРУЗКА",()->load<0?"—":load+" %");
    addStat(stats,"ДРОССЕЛЬ",()->throttle<0?"—":throttle+" %");
    LinearLayout stats2=row();stats2.setBackground(shape(PANEL,Color.rgb(18,82,128),12));LinearLayout.LayoutParams s2p=new LinearLayout.LayoutParams(-1,62);s2p.topMargin=6;page.addView(stats2,s2p);
    addStat(stats2,"ДАВЛЕНИЕ ВПУСКА",()->manifold<0?"—":manifold+" кПа");
    addStat(stats2,"MAF",()->maf<0?"—":String.format(Locale.US,"%.1f г/с",maf));
    addStat(stats2,"УГОЛ ЗАЖИГАНИЯ",()->timing<0?"—":timing+"°");
    addStat(stats2,"АТМОСФЕРА",()->barometric<0?"—":barometric+" кПа");
    obdState=text(obdMessage,11,MUTED,true);obdState.setGravity(Gravity.CENTER);page.addView(obdState,new LinearLayout.LayoutParams(-1,24));
    obdConnect=text(obdRunning?"ОТКЛЮЧИТЬ OBD2":"ПОДКЛЮЧИТЬ / ВЫБРАТЬ OBD2",13,WHITE,true);obdConnect.setGravity(Gravity.CENTER);obdConnect.setBackground(shape(Color.rgb(5,37,62),BLUE,10));page.addView(obdConnect,new LinearLayout.LayoutParams(-1,40));
    obdConnect.setOnClickListener(v->{if(obdRunning)disconnectObd();else chooseObd();});
    page.post(()->page.animate().translationY(0).setDuration(360).setInterpolator(new android.view.animation.DecelerateInterpolator()).start());
    ui.post(new Runnable(){public void run(){if(showingTrd&&rpmGauge!=null&&speedGauge!=null){rpmGauge.invalidate();speedGauge.invalidate();ui.postDelayed(this,250);}}});
  }
  private void closeTrd(View page){
    if(!showingTrd)return;showingTrd=false;
    page.animate().translationY(getResources().getDisplayMetrics().heightPixels).setDuration(300).setInterpolator(new android.view.animation.AccelerateInterpolator()).withEndAction(()->{rpmGauge=null;speedGauge=null;buildHome();}).start();
  }
  private void addStat(LinearLayout p,String label,Value value){LinearLayout c=col();c.setGravity(Gravity.CENTER);p.addView(c,new LinearLayout.LayoutParams(0,-1,1));c.addView(text(label,10,MUTED,true));TextView val=text(value.get(),17,WHITE,true);c.addView(val);ui.postDelayed(new Runnable(){public void run(){if(!isFinishing()&&showingTrd&&val.getWindowToken()!=null){val.setText(value.get());ui.postDelayed(this,500);}}},500);}
  private class GaugeView extends View{boolean isRpm;Paint p=new Paint(3);GaugeView(boolean r){super(MainActivity.this);isRpm=r;}protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),cx=w/2,cy=h*.56f,r=Math.min(w*.40f,h*.39f);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(15);p.setColor(Color.rgb(20,48,72));c.drawArc(cx-r,cy-r,cx+r,cy+r,135,270,false,p);p.setColor(BLUE);c.drawArc(cx-r,cy-r,cx+r,cy+r,135,(isRpm?rpm<0?0:Math.min(270,rpm/7000f*270):speed<0?0:Math.min(270,speed/240f*270)),false,p);int max=isRpm?7000:240;for(int i=0;i<=10;i++){double a=Math.toRadians(135+i*27);float x1=cx+(float)Math.cos(a)*(r-13),y1=cy+(float)Math.sin(a)*(r-13),x2=cx+(float)Math.cos(a)*(r+2),y2=cy+(float)Math.sin(a)*(r+2);p.setColor(WHITE);p.setStrokeWidth(3);c.drawLine(x1,y1,x2,y2,p);}float val=isRpm?rpm:speed;String number=val<0?"—":(isRpm?String.valueOf(val):String.valueOf(val));p.setStyle(Paint.Style.FILL);p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(Math.min(w*.16f,56));p.setColor(WHITE);c.drawText(number,cx,cy+12,p);p.setTextSize(16);p.setColor(BLUE);c.drawText(isRpm?"RPM":"КМ/Ч",cx,cy+38,p);p.setTextSize(12);p.setColor(MUTED);c.drawText(isRpm?"0       7 000":"0       240",cx,cy+r*.65f,p);}}
  private void chooseObd(){if(Build.VERSION.SDK_INT>=31&&checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},44);return;}try{BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();if(a==null){toast("Bluetooth недоступен");return;}if(!a.isEnabled()){toast("Включи Bluetooth в настройках магнитолы");startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));return;}Set<BluetoothDevice> devices=a.getBondedDevices();ArrayList<BluetoothDevice> obd=new ArrayList<>();for(BluetoothDevice d:devices)obd.add(d);if(obd.isEmpty()){toast("Сначала сопряги ELM327 в настройках Bluetooth Android");return;}String[] names=new String[obd.size()];for(int i=0;i<obd.size();i++)names[i]=obd.get(i).getName()+"\n"+obd.get(i).getAddress();new AlertDialog.Builder(this).setTitle("Выбрать Bluetooth OBD2").setItems(names,(d,w)->connectObd(obd.get(w))).setNegativeButton("Отмена",null).show();}catch(SecurityException e){toast("Нет разрешения Bluetooth");}}
  @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==44&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)chooseObd();else if(r==44)toast("Для Bluetooth OBD2 необходимо разрешение Bluetooth");}
  private void connectObd(BluetoothDevice device){disconnectObd();final int generation=++obdGeneration;obdMessage="ПОДКЛЮЧЕНИЕ К "+safeDeviceName(device);updateObdText();obdRunning=true;obdThread=new Thread(()->{BluetoothSocket local=null;try{try{local=device.createRfcommSocketToServiceRecord(SPP);socket=local;local.connect();}catch(IOException secureError){if(generation!=obdGeneration||!obdRunning)return;try{if(local!=null)local.close();}catch(Exception ignored){}local=device.createInsecureRfcommSocketToServiceRecord(SPP);socket=local;local.connect();}if(generation!=obdGeneration||!obdRunning)return;InputStream in=local.getInputStream();OutputStream out=local.getOutputStream();send(in,out,"ATZ");send(in,out,"ATE0");send(in,out,"ATL0");send(in,out,"ATS0");send(in,out,"ATH0");send(in,out,"ATSP0");send(in,out,"ATST64");obdMessage="OBD2 ПОДКЛЮЧЁН · "+safeDeviceName(device);postGauges();long nextDetails=0;while(obdRunning&&generation==obdGeneration&&!Thread.currentThread().isInterrupted()&&local.isConnected()){rpm=parseRpm(send(in,out,"010C"));speed=parseSpeed(send(in,out,"010D"));long now=System.currentTimeMillis();if(now>=nextDetails){coolant=parseTemp(send(in,out,"0105"));intake=parseTemp(send(in,out,"010F"));load=parsePercent(send(in,out,"0104"),"04");throttle=parsePercent(send(in,out,"0111"),"11");manifold=parseSingle(send(in,out,"010B"),"0B");maf=parseMaf(send(in,out,"0110"));timing=parseTiming(send(in,out,"010E"));barometric=parseSingle(send(in,out,"0133"),"33");nextDetails=System.currentTimeMillis()+3000;}postGauges();Thread.sleep(120);}}catch(Exception e){if(obdRunning)obdMessage="ОШИБКА OBD2: "+e.getClass().getSimpleName();}finally{try{if(local!=null)local.close();}catch(Exception ignored){}if(socket==local)socket=null;if(generation==obdGeneration){obdRunning=false;updateObdText();}}});obdThread.start();updateObdText();}
  private String safeDeviceName(BluetoothDevice d){try{return d.getName()==null?d.getAddress():d.getName();}catch(SecurityException e){return "ELM327";}}
  private String send(InputStream in,OutputStream out,String cmd)throws Exception{while(in.available()>0)in.read();out.write((cmd+"\r").getBytes(StandardCharsets.US_ASCII));out.flush();ByteArrayOutputStream b=new ByteArrayOutputStream();long end=System.currentTimeMillis()+900;while(System.currentTimeMillis()<end){if(in.available()>0){int x=in.read();if(x=='>')break;b.write(x);}else Thread.sleep(15);}return b.toString("US-ASCII").replace("\r","").replace("\n","").replace(" ","").toUpperCase(Locale.US);}
  private int[] payload(String s,String pid){Matcher m=Pattern.compile("41"+pid+"([0-9A-F]{2,})").matcher(s);if(!m.find())return null;String x=m.group(1);int[] a=new int[x.length()/2];for(int i=0;i<a.length;i++)a[i]=Integer.parseInt(x.substring(i*2,i*2+2),16);return a;}
  private int parseRpm(String s){int[] a=payload(s,"0C");return a==null||a.length<2?-1:((a[0]*256+a[1])/4);}private int parseTiming(String s){int[] a=payload(s,"0E");return a==null?-1:Math.round(a[0]/2f)-64;}private int parseSpeed(String s){int[] a=payload(s,"0D");return a==null?-1:a[0];}private int parseTemp(String s){int[] a=payload(s,"05");return a==null?-1:a[0]-40;}private int parsePercent(String s,String pid){int[] a=payload(s,pid);return a==null?-1:Math.round(a[0]*100f/255f);}private int parseSingle(String s,String pid){int[] a=payload(s,pid);return a==null?-1:a[0];}private double parseMaf(String s){int[] a=payload(s,"10");return a==null||a.length<2?-1:(a[0]*256+a[1])/100.0;}
  private void postGauges(){ui.post(()->{if(rpmGauge!=null)rpmGauge.invalidate();if(speedGauge!=null)speedGauge.invalidate();updateObdText();});}private void updateObdText(){ui.post(()->{if(obdState!=null)obdState.setText(obdMessage);if(obdConnect!=null)obdConnect.setText(obdRunning?"ОТКЛЮЧИТЬ OBD2":"ПОДКЛЮЧИТЬ / ВЫБРАТЬ OBD2");});}
  private void disconnectObd(){obdGeneration++;obdRunning=false;if(obdThread!=null)obdThread.interrupt();try{if(socket!=null)socket.close();}catch(Exception ignored){}socket=null;rpm=speed=coolant=intake=load=throttle=manifold=timing=barometric=-1;maf=-1;obdMessage="OBD2 НЕ ПОДКЛЮЧЁН";updateObdText();}

  private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
